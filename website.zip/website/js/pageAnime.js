
$(document).ready(main); // $ = jQuery library being used

function main()
{
	/* alert('Not loaded'); */
	$('.standard').hide();
	$('.standard').delay(0).slideDown(500);

	//$('.standard').css('background', 'grey');
	$('.standard').addClass('jsClass');

	//calling back to the '.standard' clicking anywhere in the '.standard' to hide or show the '.standard p'
	$('.standard').click(function()
	{     
			//$(this).find('p').slideToggle();

			//can store object to use later
			$x = $(this).find('p');
			$x.slideToggle();

	//$x.text ("This text got replaced with the JS Script");
	})
}


var x = 10;
